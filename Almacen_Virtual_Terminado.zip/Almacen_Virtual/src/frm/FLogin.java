
package frm;

import javax.swing.JOptionPane;

public class FLogin extends javax.swing.JFrame {

    static final String user = "admin";
    static final String pass = "admin";
    
    public FLogin() {
        initComponents();
        Inicio();
    }

    private void Inicio() {
        setLocationRelativeTo(null);
    }
    
    public void IniciarSesion() {
        String u = TFUsuario.getText();
        String p = new String(PFPassword.getPassword());
        //
        if (u.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this, 
                    "Escriba el nombre de usuario.", 
                    "Usuario Vacio", 
                    2
            );
            return;
        }
        if (p.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this, 
                    "Escriba la contraseña del usuario.", 
                    "Contraseña Vacia", 
                    2
            );
            return;
        }
        //
        if (u.equals(user) && p.equals(pass)) {
            //Iniciar.
            FPrincipal fp = new FPrincipal();
            dispose();
            fp.setVisible(true);
        } else {
            //Error.
            JOptionPane.showMessageDialog(
                    this, 
                    "Usuario y/o contraseña incorrectos.", 
                    "Datos Incorrectos", 
                    2
            );
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        TFUsuario = new javax.swing.JTextField();
        PFPassword = new javax.swing.JPasswordField();
        BSalir = new javax.swing.JButton();
        BIniciar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login - Almacen Virtual");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Iniciar Sesión");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 10, 280, 50);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setText("Contraseña:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 130, 110, 30);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setText("Usuario:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 90, 110, 30);

        TFUsuario.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        TFUsuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TFUsuarioKeyPressed(evt);
            }
        });
        jPanel1.add(TFUsuario);
        TFUsuario.setBounds(130, 90, 150, 30);

        PFPassword.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        PFPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PFPasswordKeyPressed(evt);
            }
        });
        jPanel1.add(PFPassword);
        PFPassword.setBounds(130, 130, 150, 30);

        BSalir.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        BSalir.setText("Salir");
        BSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSalirActionPerformed(evt);
            }
        });
        jPanel1.add(BSalir);
        BSalir.setBounds(20, 200, 100, 30);

        BIniciar.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        BIniciar.setText("Iniciar");
        BIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BIniciarActionPerformed(evt);
            }
        });
        jPanel1.add(BIniciar);
        BIniciar.setBounds(180, 200, 100, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BIniciarActionPerformed
        IniciarSesion();
    }//GEN-LAST:event_BIniciarActionPerformed

    private void BSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_BSalirActionPerformed

    private void TFUsuarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TFUsuarioKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            PFPassword.requestFocus();
        }
    }//GEN-LAST:event_TFUsuarioKeyPressed

    private void PFPasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PFPasswordKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            IniciarSesion();
        }
    }//GEN-LAST:event_PFPasswordKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BIniciar;
    private javax.swing.JButton BSalir;
    private javax.swing.JPasswordField PFPassword;
    private javax.swing.JTextField TFUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

}
