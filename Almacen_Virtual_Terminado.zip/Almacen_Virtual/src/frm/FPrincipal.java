package frm;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FPrincipal extends javax.swing.JFrame {

    DefaultTableModel almacena, almacenb;

    public FPrincipal() {
        initComponents();
        Inicio();
    }

    private void Inicio() {
        setLocationRelativeTo(null);
        almacena = (DefaultTableModel) TAlmacenA.getModel();
        TAlmacenA.setModel(almacena);
        almacenb = (DefaultTableModel) TAlmacenB.getModel();
        TAlmacenB.setModel(almacenb);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TAlmacenA = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        TAlmacenB = new javax.swing.JTable();
        TFProducto = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        SCantidad = new javax.swing.JSpinner();
        BSacarB = new javax.swing.JButton();
        BAgregarA = new javax.swing.JButton();
        BAgregarB = new javax.swing.JButton();
        BSacarA = new javax.swing.JButton();
        BEliminar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        SCantidadSacar = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Almacen Virtual");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Almacen A", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 18))); // NOI18N

        TAlmacenA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRODUCTO", "CNT"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TAlmacenA);
        if (TAlmacenA.getColumnModel().getColumnCount() > 0) {
            TAlmacenA.getColumnModel().getColumn(1).setMinWidth(80);
            TAlmacenA.getColumnModel().getColumn(1).setPreferredWidth(80);
            TAlmacenA.getColumnModel().getColumn(1).setMaxWidth(80);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 110, 240, 310);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Almacen B", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 18))); // NOI18N

        TAlmacenB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRODUCTO", "CNT"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(TAlmacenB);
        if (TAlmacenB.getColumnModel().getColumnCount() > 0) {
            TAlmacenB.getColumnModel().getColumn(1).setMinWidth(80);
            TAlmacenB.getColumnModel().getColumn(1).setPreferredWidth(80);
            TAlmacenB.getColumnModel().getColumn(1).setMaxWidth(80);
        }

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(430, 110, 240, 310);

        TFProducto.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jPanel1.add(TFProducto);
        TFProducto.setBounds(90, 20, 140, 30);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel1.setText("Producto:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 20, 70, 30);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("CNT:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(240, 20, 40, 30);

        SCantidad.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        SCantidad.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel1.add(SCantidad);
        SCantidad.setBounds(280, 20, 70, 30);

        BSacarB.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BSacarB.setText("Sacar de B");
        BSacarB.setFocusable(false);
        BSacarB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSacarBActionPerformed(evt);
            }
        });
        jPanel1.add(BSacarB);
        BSacarB.setBounds(280, 390, 130, 30);

        BAgregarA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BAgregarA.setText("Agregar A");
        BAgregarA.setFocusable(false);
        BAgregarA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BAgregarAActionPerformed(evt);
            }
        });
        jPanel1.add(BAgregarA);
        BAgregarA.setBounds(280, 110, 130, 30);

        BAgregarB.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BAgregarB.setText("Agregar B");
        BAgregarB.setFocusable(false);
        BAgregarB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BAgregarBActionPerformed(evt);
            }
        });
        jPanel1.add(BAgregarB);
        BAgregarB.setBounds(280, 150, 130, 30);

        BSacarA.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BSacarA.setText("Sacar de A");
        BSacarA.setFocusable(false);
        BSacarA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSacarAActionPerformed(evt);
            }
        });
        jPanel1.add(BSacarA);
        BSacarA.setBounds(280, 350, 130, 30);

        BEliminar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        BEliminar.setText("Eliminar");
        BEliminar.setFocusable(false);
        BEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(BEliminar);
        BEliminar.setBounds(370, 20, 100, 30);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("CNT:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(280, 310, 50, 30);

        SCantidadSacar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        SCantidadSacar.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel1.add(SCantidadSacar);
        SCantidadSacar.setBounds(330, 310, 80, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 690, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BEliminarActionPerformed
        if (TFProducto.getText().isEmpty()) {
            return;
        }
        int r = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro que desea eliminar el producto?\n\n"
                + "Producto: " + TFProducto.getText() + "\n"
                + "Cantidad: " + SCantidad.getValue(),
                "Confirmar Eliminar",
                JOptionPane.YES_NO_OPTION
        );
        if (r == 0) {
            TFProducto.setText("");
            SCantidad.setValue(1);
        }
    }//GEN-LAST:event_BEliminarActionPerformed

    private void BAgregarAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BAgregarAActionPerformed
        if (TFProducto.getText().isEmpty()) {
            return;
        }
        String producto = TFProducto.getText();
        String cantidad = SCantidad.getValue() + "";
        if (almacena.getRowCount() > 0) {
            String ultproducto = almacena.getValueAt(0, 0) + "";
            if (producto.equals(ultproducto)) {
                String cantalmacen = almacena.getValueAt(0, 1) + "";
                String cantnueva = (Integer.parseInt(cantidad) + Integer.parseInt(cantalmacen)) + "";
                almacena.setValueAt(cantnueva, 0, 1);
            } else {
                almacena.insertRow(0, new Object[]{producto, cantidad});
            }
        } else {
            almacena.insertRow(0, new Object[]{producto, cantidad});
        }
        TFProducto.setText("");
        SCantidad.setValue(1);
    }//GEN-LAST:event_BAgregarAActionPerformed

    private void BAgregarBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BAgregarBActionPerformed
        if (TFProducto.getText().isEmpty()) {
            return;
        }
        String producto = TFProducto.getText();
        String cantidad = SCantidad.getValue() + "";
        if (almacenb.getRowCount() > 0) {
            String ultproducto = almacenb.getValueAt(0, 0) + "";
            if (producto.equals(ultproducto)) {
                String cantalmacen = almacenb.getValueAt(0, 1) + "";
                String cantnueva = (Integer.parseInt(cantidad) + Integer.parseInt(cantalmacen)) + "";
                almacenb.setValueAt(cantnueva, 0, 1);
            } else {
                almacenb.insertRow(0, new Object[]{producto, cantidad});
            }
        } else {
            almacenb.insertRow(0, new Object[]{producto, cantidad});
        }
        TFProducto.setText("");
        SCantidad.setValue(1);
    }//GEN-LAST:event_BAgregarBActionPerformed

    private void BSacarAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSacarAActionPerformed
        if (almacena.getDataVector().isEmpty()) {
            return;
        }
        String producto = almacena.getValueAt(0, 0) + "";
        String cantidad = almacena.getValueAt(0, 1) + "";
        String cantsacar = SCantidadSacar.getValue() + "";
        if (Integer.parseInt(cantsacar) > Integer.parseInt(cantidad)) {
            return;
        }
        boolean actcantidad = true;
        if (!TFProducto.getText().isEmpty()) {
            String productoarriba = TFProducto.getText();
            if (producto.equals(productoarriba)) {
                String cantarriba = SCantidad.getValue() + "";
                String nuevacantarriba = (Integer.parseInt(cantarriba) + Integer.parseInt(cantsacar)) + "";
                SCantidad.setValue(Integer.parseInt(nuevacantarriba));
                actcantidad = false;
            } else {
                return;
            }
        }
        String cantalmacen = (Integer.parseInt(cantidad) - Integer.parseInt(cantsacar)) + "";
        TFProducto.setText(producto);
        if (actcantidad) {
            SCantidad.setValue(Integer.parseInt(cantsacar));
        }
        if (Integer.parseInt(cantalmacen) == 0) {
            almacena.removeRow(0);
        } else {
            almacena.setValueAt(cantalmacen, 0, 1);
        }
    }//GEN-LAST:event_BSacarAActionPerformed

    private void BSacarBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSacarBActionPerformed
        if (almacenb.getDataVector().isEmpty()) {
            return;
        }
        String producto = almacenb.getValueAt(0, 0) + "";
        String cantidad = almacenb.getValueAt(0, 1) + "";
        String cantsacar = SCantidadSacar.getValue() + "";
        if (Integer.parseInt(cantsacar) > Integer.parseInt(cantidad)) {
            return;
        }
        boolean actcantidad = true;
        if (!TFProducto.getText().isEmpty()) {
            String productoarriba = TFProducto.getText();
            if (producto.equals(productoarriba)) {
                String cantarriba = SCantidad.getValue() + "";
                String nuevacantarriba = (Integer.parseInt(cantarriba) + Integer.parseInt(cantsacar)) + "";
                SCantidad.setValue(Integer.parseInt(nuevacantarriba));
                actcantidad = false;
            } else {
                return;
            }
        }
        String cantalmacen = (Integer.parseInt(cantidad) - Integer.parseInt(cantsacar)) + "";
        TFProducto.setText(producto);
        if (actcantidad) {
            SCantidad.setValue(Integer.parseInt(cantsacar));
        }
        if (Integer.parseInt(cantalmacen) == 0) {
            almacenb.removeRow(0);
        } else {
            almacenb.setValueAt(cantalmacen, 0, 1);
        }
    }//GEN-LAST:event_BSacarBActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BAgregarA;
    private javax.swing.JButton BAgregarB;
    private javax.swing.JButton BEliminar;
    private javax.swing.JButton BSacarA;
    private javax.swing.JButton BSacarB;
    private javax.swing.JSpinner SCantidad;
    private javax.swing.JSpinner SCantidadSacar;
    private javax.swing.JTable TAlmacenA;
    private javax.swing.JTable TAlmacenB;
    private javax.swing.JTextField TFProducto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

}
