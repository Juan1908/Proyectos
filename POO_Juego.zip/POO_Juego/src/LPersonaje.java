
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

public class LPersonaje extends javax.swing.JLabel implements Runnable {

    protected int posX;
    protected int posY;
    protected int ancho;
    protected int alto;
    protected ImageIcon imagen;
    protected int Dire = 0, vida;
    protected Rectangle Rec1;

    public LPersonaje() {
        initComponents();
        setOpaque(true);
        CargarImagen("Recursos/asteroide.png");

    }

    public LPersonaje(int posX, int posY, int ancho, int alto) {
        this.posX = posX;
        this.posY = posY;
        this.ancho = ancho;
        this.alto = alto;
        setOpaque(false);
        setBounds(posX, posY, ancho, alto);
        Rec1 = new Rectangle(posX, posY, ancho, alto);
        CargarImagen("Recursos/asteroide.png");

        new Thread(this).start();

    }

    public void CargarImagen(String rutaImg) {
        imagen = new ImageIcon(getClass().getResource(rutaImg));
        setIcon(imagen);
    }

    public void mover() {
        while (true) {

            if (Dire == 0) {
                posX += 10;

            } else if (Dire == 1) {
                posX -= 10;
            }

            //rebote
            if (posX > 640) {
                Dire = 1;
            }
            if (posX < 5) {
                Dire = 0;
            }

            setBounds(posX, posY, ancho, alto);
            Rec1.setLocation(posX, posY);

            try {
                Thread.sleep(60);
            } catch (InterruptedException ex) {
                Logger.getLogger(LPersonaje.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.drawImage(imagen.getImage(), 0, 0, ancho, alto, this);

    }

    public void accionChoque(LPersonaje personaje) {
        personaje.vida--;
    }

    public boolean detectarColision(LPersonaje u) {
        if (u != null) {
            if (Rec1.intersects(u.getRec1())) {
                u.accionChoque(this);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
        
    }

    public Rectangle getRec1() {

        return Rec1;
    }

    public void setRec1(Rectangle Rec1) {

        this.Rec1 = Rec1;

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(50, 50));
    }// </editor-fold>//GEN-END:initComponents

    @Override
    public void run() {
        mover();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
