
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LJugador extends LPersonaje {

    public static int direccion;
    protected Rectangle Rec2;
    int rotar;

    public LJugador() {
        initComponents();
        CargarImagen("Recursos/nave.png");

    }

    public LJugador(int posX, int posY, int ancho, int alto) {
        this.posX = posX;
        this.posY = posY;
        this.ancho = ancho;
        this.alto = alto;
        vida = 5;
        setOpaque(false);
        setBounds(posX, posY, ancho, alto);
        Rec1 = new Rectangle(posX, posY, ancho, alto);
        CargarImagen("Recursos/nave.png");

        new Thread(this).start();
    }

    @Override
    public void mover() {

        while (true) {
            switch (direccion) {
                case KeyEvent.VK_RIGHT:
                    CargarImagen("Recursos/naveD.png");
                    posX += 10;
                    break;
                case KeyEvent.VK_LEFT:
                    CargarImagen("Recursos/naveI.png");
                   posX -= 10;
                    break;
                case KeyEvent.VK_DOWN:
                    CargarImagen("Recursos/naveA.png");
                    posY += 10;
                    break;
                case KeyEvent.VK_UP:
                    CargarImagen("Recursos/nave.png");
                    posY -= 10;
                    break;

            }

            if (posX == -100) {
                posX += 720;

            } else if (posX > 690) {
                posX -= 740;

            } else if (posY == -100) {
                posY += 570;

            } else if (posY > 550) {
                posY -= 600;

            }

            

            setBounds(posX, posY, ancho, alto);
            Rec1.setLocation(posX, posY);
            for (int j = 0; j < PCanvas.numAsteroides; j++) {
                boolean colis = detectarColision(PCanvas.personajes[j]);
                if (colis) {
                    //System.out.println("Choque detectado");
                }
            }
            try {
                Thread.sleep(70);
            } catch (InterruptedException ex) {
                Logger.getLogger(LPersonaje.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    


    @Override
    public void accionChoque(LPersonaje personaje) {

    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
