
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class PCanvas extends javax.swing.JPanel {

    static LPersonaje[] personajes;
    Image fondo, vida;
    LJugador player;
    static int numAsteroides = 0;

    public PCanvas() {
        initComponents();
        fondo = new ImageIcon(getClass().getResource("Recursos/fondo.jpg")).getImage();
        vida = new ImageIcon(getClass().getResource("Recursos/heart.png")).getImage();
        personajes = new LPersonaje[10];
        
        Cronometro con = new Cronometro(this);
        add(con.ficha);
        
        player = new LJugador(150, 300, 61, 61);
        add(player);

        LPersonaje asteroide = new LPersonaje(200, 50, 60, 60);
        add(asteroide);

        LPersonaje2 luna = new LPersonaje2(10, 80, 60, 60);
        add(luna);

        LPersonaje3 piedra = new LPersonaje3(400, 200, 80, 80);
        add(piedra);
        
        
        
        
        personajes[0] = asteroide;
        personajes[1] = luna;
        personajes[2] = piedra;
        numAsteroides = 3;
        //personajes[3] = lok;
        
       
        
    }

    @Override
    public void paint(Graphics g) {

        //super.paint(g);
        g.drawImage(fondo, 0, 0, getWidth(), getHeight(), null);
        paintComponents(g);
        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Vidas: ", 270, 30);
        for (int i = 0; i < player.vida; i++) {
            if (player.vida <= 10 && player.vida > 1) {
                g.drawImage(vida, 330 + (i * 30), 5, 40, 40, null);
                repaint();
            } else if (player.vida > 10) {
                player.vida = 10;
            } else if (player.vida <= 1) {
                player.vida = 0;
                repaint();
                JOptionPane.showMessageDialog(null, "El juego se ha terminado");
                System.exit(0);
            }
        }

        g.drawString("Tiempo: ", 20, 30);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(255, 255, 255));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 398, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked
        if (evt.getButton() == 1) {
            LPersonaje asteroide = new LPersonaje(evt.getX(), evt.getY(), 50, 50);
            add(asteroide);
        } else if (evt.getButton() == 3) {
            LPersonaje2 luna = new LPersonaje2(evt.getX(), evt.getY(), 60, 60);
            add(luna);
        }

        repaint();

    }//GEN-LAST:event_formMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
