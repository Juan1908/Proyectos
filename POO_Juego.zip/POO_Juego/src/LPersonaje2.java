

import java.awt.Rectangle;
import java.util.logging.Level;
import java.util.logging.Logger;




public class LPersonaje2 extends LPersonaje {

    protected int posX;
    protected int posY;
    protected int ancho;
    protected int alto;
    private final int VEL = 10;
    protected int Dire = 7;
    protected Rectangle Rec3;

    public LPersonaje2() {
        initComponents();
        CargarImagen("Recursos/luna.png");
        
    }

    public LPersonaje2(int posX, int posY, int ancho, int alto) {
        this.posX = posX;
        this.posY = posY;
        this.ancho = ancho;
        this.alto = alto;
        setOpaque(false);
        setBounds(posX, posY, ancho, alto);
        Rec1 = new Rectangle(posX, posY, ancho, alto);
        CargarImagen("Recursos/luna.png");
        
        new Thread(this).start();
    }
    
    
    
    @Override
    public void mover(){
        while (true) {
            //Definir direcciones
            switch (Dire) {
                case 0:
                    posY += VEL;
                    break;
                case 1:
                    posY -= VEL;
                    break;
                case 2:
                    posX += VEL;
                    break;
                case 3:
                    posX -= VEL;
                    break;
                case 4:
                    posX += VEL;
                    posY += VEL;
                    break;
                case 5:
                    posX -= VEL;
                    posY -= VEL;
                    break;
                case 6:
                    posX -= VEL;
                    posY += VEL;
                    break;
                case 7:
                    posX += VEL;
                    posY -= VEL;
                    break;
                default:
                    break;
            }
            
            //rebotar
            
            if (posY <= 0) {
                int numRan = (int)(Math.random() * 2)+ 1;
                Dire = (numRan == 1) ? 6 : numRan == 2 ? 4 : 4;
            } else if (posX <= 0) {
                int numRan = (int)(Math.random() * 2)+1;
                Dire = (numRan == 1) ? 4 : numRan == 2 ? 7 : 7;
            } else if (posY >= 420) {
                int numRan = (int)(Math.random() * 2)+1;
                Dire = (numRan == 1) ? 7 : numRan == 2 ? 5 : 5;
            } else if (posX >= 640) {
                int numRan = (int)(Math.random() * 2)+1;
                Dire = (numRan == 1) ? 5 : numRan == 2 ? 6 : 6;
            }
            setBounds(posX, posY, ancho, alto);
            Rec1.setLocation(posX, posY);
            try {
                Thread.sleep(70);
            } catch (InterruptedException ex) {
                Logger.getLogger(LPersonaje2.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        
    }
    
    @Override
    public void accionChoque(LPersonaje personaje){
        personaje.vida++;
        
    }
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
    }// </editor-fold>//GEN-END:initComponents
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
