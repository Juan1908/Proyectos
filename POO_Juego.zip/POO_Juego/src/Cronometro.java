
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Cronometro extends LPersonaje {

    static int minutos, segundos;
    JLabel ficha;
    PCanvas lienzo;

    public Cronometro(PCanvas lienzo) {
        this.lienzo = lienzo;
        ficha = new JLabel("");
        ficha.setBounds(100, 13, 80, 20);
        ficha.setForeground(Color.white);
        ficha.setFont(new Font("Arial", Font.BOLD, 20));
        new Thread(this).start();

    }

    @Override
    public void mover() {
        for (minutos = 0; minutos < 60; minutos++) {
            if (minutos == 2) {
                
                JOptionPane.showMessageDialog(null, "Tu tiempo se acabo");
                System.exit(0);
            } else if (minutos == 1 && segundos == 30) {
                System.out.println("\nTe quedan 30 segundos!!!");
            } else if (minutos == 1 && segundos == 50) {
                System.out.println("Te queda un minuto");
            }
            for (segundos = 0; segundos < 60; segundos++) {
                ficha.setText(minutos + " : " + segundos);
                conSegundos();
                //System.out.println(""+segundos);
                
                if (segundos == 20) {
                    LPersonaje lok = new LPersonaje(0, 280, 60, 60);
                    lienzo.add(lok);
                    
                    PCanvas.personajes[PCanvas.numAsteroides] = lok;
                    PCanvas.numAsteroides++;
                } else if (segundos == 30) {
                    LPersonaje lok = new LPersonaje(0, 410, 60, 60);
                    lienzo.add(lok);
                    
                    PCanvas.personajes[PCanvas.numAsteroides] = lok;
                    PCanvas.numAsteroides++;
                }else if (segundos == 40) {
                    LPersonaje lok = new LPersonaje(0, 150, 60, 60);
                    lienzo.add(lok);
                    
                    PCanvas.personajes[PCanvas.numAsteroides] = lok;
                    PCanvas.numAsteroides++;
                }

            }
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); 
        paintComponents(g);
    }
    
    

    public static void conSegundos() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(PCanvas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
