
import java.awt.Rectangle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class LPersonaje3 extends LPersonaje{
    protected int posX;
    protected int posY;
    protected int ancho;
    protected int alto;
    protected int Dire = 0;
    protected Rectangle Rec3;

    public LPersonaje3() {
        initComponents();
        CargarImagen("Recursos/rocka.png");
        
    }

    public LPersonaje3(int posX, int posY, int ancho, int alto) {
        this.posX = posX;
        this.posY = posY;
        this.ancho = ancho;
        this.alto = alto;
        setOpaque(false);
        setBounds(posX, posY, ancho, alto);
        Rec1 = new Rectangle(posX, posY, ancho, alto);
        CargarImagen("Recursos/rocka.png");
        
        new Thread(this).start();
    }
    
    
    
    @Override
    public void mover(){
        while (true) {

            if (Dire == 0) {
                posX += 10;

            } else if (Dire == 1) {
                posX -= 10;
            }

            //rebote
            if (posX > 610) {
                Dire = 1;
            }
            if (posX < 5) {
                Dire = 0;
            }

            setBounds(posX, posY, ancho, alto);
            Rec1.setLocation(posX, posY);

            try {
                Thread.sleep(80);
            } catch (InterruptedException ex) {
                Logger.getLogger(LPersonaje.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    @Override
    public void accionChoque(LPersonaje personaje){
        JOptionPane.showMessageDialog(labelFor, "Has sido eliminado");
        System.exit(0);
        
    }
    
    
    @SuppressWarnings("unchecked")
    private void initComponents() {
    }
}
