
import javax.swing.JButton;
import javax.swing.JOptionPane;


public class GATO extends javax.swing.JFrame {

    String jugador;
    int contadorX, contadorO;

    public GATO() {
        initComponents();
        this.setLocationRelativeTo(null);

        jugador = "X";
        contadorX = 0;
        contadorO = 0;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BC1 = new javax.swing.JButton();
        BC2 = new javax.swing.JButton();
        BC3 = new javax.swing.JButton();
        BC4 = new javax.swing.JButton();
        BC5 = new javax.swing.JButton();
        BC6 = new javax.swing.JButton();
        BC7 = new javax.swing.JButton();
        BC8 = new javax.swing.JButton();
        BC9 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("MARCADOR: X=  O= ");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(406, 400));
        jPanel1.setLayout(new java.awt.GridLayout(3, 3));

        BC1.setBackground(new java.awt.Color(255, 255, 255));
        BC1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC1.setForeground(new java.awt.Color(0, 0, 255));
        BC1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC1MouseClicked(evt);
            }
        });
        jPanel1.add(BC1);

        BC2.setBackground(new java.awt.Color(255, 255, 255));
        BC2.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC2.setForeground(new java.awt.Color(0, 0, 255));
        BC2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC2MouseClicked(evt);
            }
        });
        jPanel1.add(BC2);

        BC3.setBackground(new java.awt.Color(255, 255, 255));
        BC3.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC3.setForeground(new java.awt.Color(0, 0, 255));
        BC3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC3MouseClicked(evt);
            }
        });
        jPanel1.add(BC3);

        BC4.setBackground(new java.awt.Color(255, 255, 255));
        BC4.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC4.setForeground(new java.awt.Color(0, 0, 255));
        BC4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC4MouseClicked(evt);
            }
        });
        jPanel1.add(BC4);

        BC5.setBackground(new java.awt.Color(255, 255, 255));
        BC5.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC5.setForeground(new java.awt.Color(0, 0, 255));
        BC5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC5MouseClicked(evt);
            }
        });
        jPanel1.add(BC5);

        BC6.setBackground(new java.awt.Color(255, 255, 255));
        BC6.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC6.setForeground(new java.awt.Color(0, 0, 255));
        BC6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC6MouseClicked(evt);
            }
        });
        jPanel1.add(BC6);

        BC7.setBackground(new java.awt.Color(255, 255, 255));
        BC7.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC7.setForeground(new java.awt.Color(0, 0, 255));
        BC7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC7MouseClicked(evt);
            }
        });
        jPanel1.add(BC7);

        BC8.setBackground(new java.awt.Color(255, 255, 255));
        BC8.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC8.setForeground(new java.awt.Color(0, 0, 255));
        BC8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC8MouseClicked(evt);
            }
        });
        jPanel1.add(BC8);

        BC9.setBackground(new java.awt.Color(255, 255, 255));
        BC9.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        BC9.setForeground(new java.awt.Color(0, 0, 255));
        BC9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BC9MouseClicked(evt);
            }
        });
        jPanel1.add(BC9);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 403, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BC1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC1MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC1MouseClicked

    private void BC2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC2MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC2MouseClicked

    private void BC3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC3MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC3MouseClicked

    private void BC4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC4MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC4MouseClicked

    private void BC5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC5MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC5MouseClicked

    private void BC6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC6MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC6MouseClicked

    private void BC7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC7MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC7MouseClicked

    private void BC8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC8MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC8MouseClicked

    private void BC9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BC9MouseClicked
        jugar(evt);
    }//GEN-LAST:event_BC9MouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        cerrar();
    }//GEN-LAST:event_formWindowClosing

    public void jugar(java.awt.event.MouseEvent evt) {
        JButton btn = (JButton) evt.getSource();
        btn.setText(jugador);
        Validar();
        if (jugador.equals("X")) {
            jugador = "O";
        } else {
            jugador = "X";
        }
    }

    public void Validar() {
        String c1 = BC1.getText();
        String c2 = BC2.getText();
        String c3 = BC3.getText();
        String c4 = BC4.getText();
        String c5 = BC5.getText();
        String c6 = BC6.getText();
        String c7 = BC7.getText();
        String c8 = BC8.getText();
        String c9 = BC9.getText();

        //Cuando se gana en los lados
        if ((c1.equals("X") && c2.equals("X") && c3.equals("X"))
                || (c1.equals("X") && c4.equals("X") && c7.equals("X"))
                || (c7.equals("X") && c8.equals("X") && c9.equals("X"))
                || (c3.equals("X") && c6.equals("X") && c9.equals("X"))) {

            contadorX++;
            JOptionPane.showMessageDialog(null, "Jugador X ha ganado");
            this.setTitle("MARCADOR: X=" + contadorX + " O=" + contadorO);
            BorrarLineas();
        }
        if ((c1.equals("O") && c2.equals("O") && c3.equals("O"))
                || (c1.equals("O") && c4.equals("O") && c7.equals("O"))
                || (c7.equals("O") && c8.equals("O") && c9.equals("O"))
                || (c3.equals("O") && c6.equals("O") && c9.equals("O"))) {

            contadorO++;
            JOptionPane.showMessageDialog(null, "Jugador O ha ganado");
            this.setTitle("MARCADOR: X=" + contadorX + " O=" + contadorO);
            BorrarLineas();
        }

        //Cuando se gana en cruz
        if ((c2.equals("X") && c5.equals("X") && c8.equals("X"))
                || (c4.equals("X") && c5.equals("X") && c6.equals("X"))) {

            contadorX++;
            JOptionPane.showMessageDialog(null, "Jugador X ha ganado");
            this.setTitle("MARCADOR: X=" + contadorX + " O=" + contadorO);
            BorrarLineas();
        }
        if ((c2.equals("O") && c5.equals("O") && c8.equals("O"))
                || (c4.equals("O") && c5.equals("O") && c6.equals("O"))) {

            contadorO++;
            JOptionPane.showMessageDialog(null, "Jugador O ha ganado");
            this.setTitle("MARCADOR: X=" + contadorX + " O=" + contadorO);
            BorrarLineas();
        }

        //Cuando se gana en diagonal
        if ((c1.equals("X") && c5.equals("X") && c9.equals("X"))
                || (c3.equals("X") && c5.equals("X") && c7.equals("X"))) {

            contadorX++;
            JOptionPane.showMessageDialog(null, "Jugador X ha ganado");
            this.setTitle("MARCADOR: X=" + contadorX + " O=" + contadorO);
            BorrarLineas();
        }
        if ((c1.equals("O") && c5.equals("O") && c9.equals("O"))
                || (c3.equals("O") && c5.equals("O") && c7.equals("O"))) {

            contadorO++;
            JOptionPane.showMessageDialog(null, "Jugador O ha ganado");
            this.setTitle("MARCADOR: X=" + contadorX + " O=" + contadorO);
            BorrarLineas();
        }

    }

    public void BorrarLineas() {
        BC1.setText("");
        BC2.setText("");
        BC3.setText("");
        BC4.setText("");
        BC5.setText("");
        BC6.setText("");
        BC7.setText("");
        BC8.setText("");
        BC9.setText("");
    }

    public void cerrar() {
        Object[] opciones = {"Aceptar", "Cancelar", "Comentarios"};
        int eleccion = JOptionPane.showOptionDialog(rootPane, "Marcador final: X= " + contadorX + " O= " + contadorO
                + "\n¿Desea terminar el juego?", "Ventana de cierre",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, opciones, "Aceptar");
        if (eleccion == JOptionPane.YES_OPTION) {
            System.exit(0);
        } else {
        }

    }

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GATO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GATO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GATO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GATO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GATO().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BC1;
    private javax.swing.JButton BC2;
    private javax.swing.JButton BC3;
    private javax.swing.JButton BC4;
    private javax.swing.JButton BC5;
    private javax.swing.JButton BC6;
    private javax.swing.JButton BC7;
    private javax.swing.JButton BC8;
    private javax.swing.JButton BC9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
